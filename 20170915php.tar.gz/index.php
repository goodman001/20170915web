<!DOCTYPE HTML>
<html>
<?php session_start(); ?>
<head>
    <title>Famox</title>
    <meta http-equiv="Content-Type" content="text/html; UTF-8" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
	
</head>
<body>
	<?php include 'public/nav.php';?>
	<div class=" bg">
	<div class="contain">
		<div class="c_title">
			<h2 >Welcome to Famox</h2>
		</div>
	</div>

   </div>
<script src="js/jquery-1.11.1.min.js"></script>
</body>
</html>
